/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package svm.auxiliar.file;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 *
 * @author Coelho
 */
public class Text_Filter extends FileFilter {
    @Override
    public boolean accept(File f) {
        if (Files.getExtension(f) != null)
            return Files.getExtension(f).equals("txt") || Files.getExtension(f).equals("TXT") || f.isDirectory();
        else if (f.isDirectory())
            return true;
        return false;
    }

    @Override
    public String getDescription() {
        return "*.txt";
    }    
}
