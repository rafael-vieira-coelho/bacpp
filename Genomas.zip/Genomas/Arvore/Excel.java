package svm.auxiliar.file;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Excel {

    public static void exportToFile(String fileName, ArrayList<String> data) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet firstSheet = workbook.createSheet("Results");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(new File(fileName));
            HSSFCellStyle style = workbook.createCellStyle();
            HSSFFont font = workbook.createFont();
            
            font.setFontName(HSSFFont.FONT_ARIAL);
            font.setFontHeightInPoints((short) 10);
            font.setBold(true);
            style.setFont(font);
            HSSFRow row = firstSheet.createRow(0);
            
            row.createCell(0).setCellValue("Fold");
            row.createCell(1).setCellValue("Model");
            row.createCell(2).setCellValue("Type");
            row.createCell(3).setCellValue("Kernel");
            row.createCell(4).setCellValue("Cost(C)");
            row.createCell(5).setCellValue("Gamma(G)");
            row.createCell(6).setCellValue("RMS");
            row.createCell(7).setCellValue("Accuracy(A)");
            row.createCell(8).setCellValue("Specificity(S)");
            row.createCell(9).setCellValue("Sensibility(SN)");
            row.createCell(10).setCellValue("Accepted");
            row.setRowStyle(style);
            int i = 1;

            for (String line : data) {
                String values[] = line.split("#");

                row = firstSheet.createRow(i);
                for (int j = 0; j < values.length; j++) {
                    row.createCell(j).setCellValue(values[j]);
                }
                i++;
            }
            for (int j = 0; j < 10; j++) {
                firstSheet.autoSizeColumn(j);
            }
            firstSheet.setHorizontallyCenter(true);
            firstSheet.setVerticallyCenter(true);
            workbook.write(fos);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Erro ao exportar arquivo");
        } finally {
            try {
                fos.flush();
                fos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
