/**
 * @description List of directory.
 */
package svm.auxiliar.file;

import javax.swing.ProgressMonitor;

/**
 * @author Rafael Coelho
 * @version 23/08/2015
 */
public class Folders {

    public static final String OUTPUT = ".\\_Data\\Output\\";
    public static final String FOLDS = OUTPUT + "Folds\\";
    public static final String MODELS = OUTPUT + "Models\\";
    public static final String NET = OUTPUT + "Net\\";
    public static final String RESULTS = OUTPUT + "Results\\";
    public static final String STATISTICS = OUTPUT + "Statistics\\";
    public static final String STEP1 = STATISTICS + "Step1\\";
    public static final String STEP2 = STATISTICS + "Step2\\";
    public static final String STEP3 = STATISTICS + "Step3\\";

    public static final String TEST = NET + "Test\\";
    public static final String TRAIN = NET + "Train\\";

    public static final String INPUT = ".\\_Data\\Input\\";
    public static final String PROMOTERS = INPUT + "Promoters\\";

    public static final String PYTHON = ".\\_Python\\";    
    public static final String CURRENT = ".\\";

    /**
     * Delete files from folder.
     *
     * @param folderName
     * @param progressMonitor
     */
    public static void deleteOldFiles(String folderName, ProgressMonitor progressMonitor) {
        TextFile diretorio = new TextFile(folderName);

        diretorio.deleteFilesFromFolder(progressMonitor);
    }

    public static void deleteOldFiles(String folderName) {
        TextFile diretorio = new TextFile(folderName);

        diretorio.deleteFilesFromFolder();
    }

}
